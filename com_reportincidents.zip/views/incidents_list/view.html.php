<?php
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class ReportincidentsViewincidents_list extends JViewLegacy
{
    function display($tpl = null)
    {

        parent::display($tpl);
    }
}
