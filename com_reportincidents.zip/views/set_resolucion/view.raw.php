<?php
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class ReportincidentsViewset_resolucion extends JViewLegacy
{
    function display($tpl = null)
    {

        parent::display($tpl);
    }
}
