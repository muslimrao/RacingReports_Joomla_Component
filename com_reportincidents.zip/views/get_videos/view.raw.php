<?php
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class ReportincidentsViewget_videos extends JViewLegacy
{
    function display($tpl = null)
    {

        parent::display($tpl);
    }
}
