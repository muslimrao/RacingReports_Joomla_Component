<?php
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class ReportincidentsViewget_guilty_video extends JViewLegacy
{
    function display($tpl = null)
    {

        parent::display($tpl);
    }
}
